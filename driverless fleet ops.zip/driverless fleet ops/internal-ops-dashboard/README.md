# Internal Operations Dashboard

A lightweight React/TypeScript sample showing how an internal team could monitor vehicles and dispatch status.

The goal is not visual perfection. The goal is to show product-facing thinking:
- surface operational status clearly
- keep API communication typed
- keep UI components simple and maintainable
- design for fast iteration
