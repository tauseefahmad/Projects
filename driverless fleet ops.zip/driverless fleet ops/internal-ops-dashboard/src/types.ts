export type VehicleStatus = "available" | "assigned" | "charging" | "maintenance" | "offline";

export interface Vehicle {
  externalId: string;
  displayName: string;
  city: string;
  status: VehicleStatus;
  batteryPercent: number;
  lastSeenAt: string;
}
