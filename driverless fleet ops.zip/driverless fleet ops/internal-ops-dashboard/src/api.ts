import type { Vehicle } from "./types";

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL ?? "http://localhost:8080";

export async function fetchVehicles(): Promise<Vehicle[]> {
  const response = await fetch(`${API_BASE_URL}/api/vehicles`);

  if (!response.ok) {
    throw new Error(`Vehicle request failed with status ${response.status}`);
  }

  const payload = await response.json();
  return payload.data;
}
