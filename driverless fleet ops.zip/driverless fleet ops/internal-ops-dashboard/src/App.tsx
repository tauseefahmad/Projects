import { useEffect, useState } from "react";
import { fetchVehicles } from "./api";
import type { Vehicle } from "./types";
import "./styles.css";

export default function App() {
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchVehicles()
      .then(setVehicles)
      .catch((err: Error) => setError(err.message));
  }, []);

  const available = vehicles.filter((vehicle) => vehicle.status === "available").length;
  const needsAttention = vehicles.filter((vehicle) =>
    ["maintenance", "offline"].includes(vehicle.status)
  ).length;

  return (
    <main className="page">
      <header>
        <p className="eyebrow">Internal Operations</p>
        <h1>Driverless Fleet Dashboard</h1>
        <p className="subtitle">Compact operations view for vehicles, status and reliability signals.</p>
      </header>

      {error ? <section className="alert">Unable to load vehicles: {error}</section> : null}

      <section className="metrics">
        <Metric label="Total vehicles" value={vehicles.length} />
        <Metric label="Available" value={available} />
        <Metric label="Needs attention" value={needsAttention} />
      </section>

      <section className="card">
        <h2>Vehicle status</h2>
        <table>
          <thead>
            <tr>
              <th>Vehicle</th>
              <th>City</th>
              <th>Status</th>
              <th>Battery</th>
              <th>Last seen</th>
            </tr>
          </thead>
          <tbody>
            {vehicles.map((vehicle) => (
              <tr key={vehicle.externalId}>
                <td>{vehicle.displayName}</td>
                <td>{vehicle.city}</td>
                <td>{vehicle.status}</td>
                <td>{vehicle.batteryPercent}%</td>
                <td>{new Date(vehicle.lastSeenAt).toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>
    </main>
  );
}

function Metric({ label, value }: { label: string; value: number }) {
  return (
    <article className="metric">
      <span>{label}</span>
      <strong>{value}</strong>
    </article>
  );
}
