import dotenv from "dotenv";

dotenv.config();

export const config = {
  port: Number(process.env.PORT ?? 8080),
  mongoUri: process.env.MONGODB_URI ?? "mongodb://localhost:27017/fleet_ops",
  nodeEnv: process.env.NODE_ENV ?? "development"
};
