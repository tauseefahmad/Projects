import { createApp } from "./app";
import { config } from "./config";
import { connectDatabase } from "./db";

async function start() {
  await connectDatabase();
  const app = createApp();

  app.listen(config.port, () => {
    console.info(`Fleet operations API listening on port ${config.port}`);
  });
}

start().catch((error) => {
  console.error("Failed to start service", error);
  process.exit(1);
});
