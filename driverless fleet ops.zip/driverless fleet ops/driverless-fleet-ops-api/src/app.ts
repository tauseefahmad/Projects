import express from "express";
import cors from "cors";
import helmet from "helmet";
import { errorHandler } from "./middleware/errorHandler";
import { requestLogger } from "./middleware/requestLogger";
import { healthRouter } from "./modules/health/health.routes";
import { vehicleRouter } from "./modules/vehicles/vehicle.routes";
import { dispatchJobRouter } from "./modules/dispatchJobs/dispatchJob.routes";

export function createApp() {
  const app = express();

  app.use(helmet());
  app.use(cors());
  app.use(express.json({ limit: "1mb" }));
  app.use(requestLogger);

  app.use("/health", healthRouter);
  app.use("/api/vehicles", vehicleRouter);
  app.use("/api/dispatch-jobs", dispatchJobRouter);

  app.use(errorHandler);
  return app;
}
