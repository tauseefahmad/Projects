import type { ErrorRequestHandler } from "express";
import { ZodError } from "zod";
import { AppError } from "../errors";

export const errorHandler: ErrorRequestHandler = (error, _req, res, _next) => {
  if (error instanceof ZodError) {
    return res.status(400).json({
      error: "ValidationError",
      message: "Request payload failed validation",
      details: error.flatten()
    });
  }

  if (error instanceof AppError) {
    return res.status(error.statusCode).json({
      error: "ApplicationError",
      message: error.message,
      details: error.details
    });
  }

  console.error(error);
  return res.status(500).json({
    error: "InternalServerError",
    message: "Unexpected server error"
  });
};
