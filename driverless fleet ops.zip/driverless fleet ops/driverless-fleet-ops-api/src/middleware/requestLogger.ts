import type { RequestHandler } from "express";
import { randomUUID } from "crypto";

export const requestLogger: RequestHandler = (req, _res, next) => {
  const requestId = req.header("x-request-id") ?? randomUUID();
  req.headers["x-request-id"] = requestId;
  console.info(`[${requestId}] ${req.method} ${req.originalUrl}`);
  next();
};
