import { Router } from "express";
import { createDispatchJobSchema } from "./dispatchJob.schema";
import { completeDispatchJob, createDispatchJob, listDispatchJobs } from "./dispatchJob.service";

export const dispatchJobRouter = Router();

dispatchJobRouter.get("/", async (_req, res, next) => {
  try {
    const jobs = await listDispatchJobs();
    res.json({ data: jobs });
  } catch (error) {
    next(error);
  }
});

dispatchJobRouter.post("/", async (req, res, next) => {
  try {
    const input = createDispatchJobSchema.parse(req.body);
    const job = await createDispatchJob(input);
    res.status(201).json({ data: job });
  } catch (error) {
    next(error);
  }
});

dispatchJobRouter.patch("/:id/complete", async (req, res, next) => {
  try {
    const job = await completeDispatchJob(req.params.id);
    res.json({ data: job });
  } catch (error) {
    next(error);
  }
});
