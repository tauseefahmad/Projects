import mongoose, { Schema, InferSchemaType } from "mongoose";

const dispatchJobSchema = new Schema(
  {
    vehicleExternalId: { type: String, required: true, index: true },
    pickupLocation: {
      lat: { type: Number, required: true },
      lng: { type: Number, required: true }
    },
    dropoffLocation: {
      lat: { type: Number, required: true },
      lng: { type: Number, required: true }
    },
    status: {
      type: String,
      enum: ["queued", "assigned", "in_progress", "completed", "cancelled"],
      required: true,
      default: "queued"
    },
    requestedBy: { type: String, required: true }
  },
  { timestamps: true }
);

export type DispatchJobDocument = InferSchemaType<typeof dispatchJobSchema>;
export const DispatchJobModel = mongoose.model("DispatchJob", dispatchJobSchema);
