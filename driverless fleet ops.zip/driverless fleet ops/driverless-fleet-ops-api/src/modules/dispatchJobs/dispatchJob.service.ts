import { AppError, notFound } from "../../errors";
import { VehicleModel } from "../vehicles/vehicle.model";
import { DispatchJobModel } from "./dispatchJob.model";

export async function listDispatchJobs() {
  return DispatchJobModel.find().sort({ createdAt: -1 }).limit(100).lean();
}

export async function createDispatchJob(input: {
  vehicleExternalId: string;
  pickupLocation: { lat: number; lng: number };
  dropoffLocation: { lat: number; lng: number };
  requestedBy: string;
}) {
  const vehicle = await VehicleModel.findOne({ externalId: input.vehicleExternalId });

  if (!vehicle) throw notFound("Vehicle");
  if (vehicle.status !== "available") {
    throw new AppError(409, "Vehicle is not available for assignment", {
      vehicleExternalId: vehicle.externalId,
      currentStatus: vehicle.status
    });
  }

  const job = await DispatchJobModel.create({ ...input, status: "assigned" });

  vehicle.status = "assigned";
  vehicle.lastSeenAt = new Date();
  await vehicle.save();

  return job;
}

export async function completeDispatchJob(id: string) {
  const job = await DispatchJobModel.findById(id);
  if (!job) throw notFound("Dispatch job");

  if (job.status === "completed") return job;

  job.status = "completed";
  await job.save();

  await VehicleModel.findOneAndUpdate(
    { externalId: job.vehicleExternalId },
    { status: "available", lastSeenAt: new Date() },
    { runValidators: true }
  );

  return job;
}
