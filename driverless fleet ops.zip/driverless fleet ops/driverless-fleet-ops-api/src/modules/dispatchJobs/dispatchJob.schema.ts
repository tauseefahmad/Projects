import { z } from "zod";

const coordinateSchema = z.object({
  lat: z.number().min(-90).max(90),
  lng: z.number().min(-180).max(180)
});

export const createDispatchJobSchema = z.object({
  vehicleExternalId: z.string().min(3).max(80),
  pickupLocation: coordinateSchema,
  dropoffLocation: coordinateSchema,
  requestedBy: z.string().min(2).max(120)
});
