import { VehicleModel } from "./vehicle.model";
import { notFound } from "../../errors";

export async function listVehicles(city?: string) {
  const filter = city ? { city } : {};
  return VehicleModel.find(filter).sort({ city: 1, displayName: 1 }).lean();
}

export async function createVehicle(input: {
  externalId: string;
  displayName: string;
  city: string;
  batteryPercent: number;
  status: "available" | "assigned" | "charging" | "maintenance" | "offline";
}) {
  return VehicleModel.create({
    ...input,
    lastSeenAt: new Date()
  });
}

export async function updateVehicleStatus(
  id: string,
  input: {
    status: "available" | "assigned" | "charging" | "maintenance" | "offline";
    batteryPercent?: number;
  }
) {
  const updated = await VehicleModel.findByIdAndUpdate(
    id,
    { ...input, lastSeenAt: new Date() },
    { new: true, runValidators: true }
  );

  if (!updated) throw notFound("Vehicle");
  return updated;
}
