import mongoose, { Schema, InferSchemaType } from "mongoose";

const vehicleSchema = new Schema(
  {
    externalId: { type: String, required: true, unique: true, index: true },
    displayName: { type: String, required: true },
    status: {
      type: String,
      enum: ["available", "assigned", "charging", "maintenance", "offline"],
      required: true,
      default: "offline"
    },
    city: { type: String, required: true },
    batteryPercent: { type: Number, min: 0, max: 100, required: true },
    lastSeenAt: { type: Date, required: true }
  },
  { timestamps: true }
);

export type VehicleDocument = InferSchemaType<typeof vehicleSchema>;
export const VehicleModel = mongoose.model("Vehicle", vehicleSchema);
