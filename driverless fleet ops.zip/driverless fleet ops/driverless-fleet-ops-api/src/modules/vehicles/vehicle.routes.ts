import { Router } from "express";
import { createVehicleSchema, updateVehicleStatusSchema } from "./vehicle.schema";
import { createVehicle, listVehicles, updateVehicleStatus } from "./vehicle.service";

export const vehicleRouter = Router();

vehicleRouter.get("/", async (req, res, next) => {
  try {
    const city = typeof req.query.city === "string" ? req.query.city : undefined;
    const vehicles = await listVehicles(city);
    res.json({ data: vehicles });
  } catch (error) {
    next(error);
  }
});

vehicleRouter.post("/", async (req, res, next) => {
  try {
    const input = createVehicleSchema.parse(req.body);
    const vehicle = await createVehicle(input);
    res.status(201).json({ data: vehicle });
  } catch (error) {
    next(error);
  }
});

vehicleRouter.patch("/:id/status", async (req, res, next) => {
  try {
    const input = updateVehicleStatusSchema.parse(req.body);
    const vehicle = await updateVehicleStatus(req.params.id, input);
    res.json({ data: vehicle });
  } catch (error) {
    next(error);
  }
});
