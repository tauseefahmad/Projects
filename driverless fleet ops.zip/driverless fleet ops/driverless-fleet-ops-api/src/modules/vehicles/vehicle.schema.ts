import { z } from "zod";

export const createVehicleSchema = z.object({
  externalId: z.string().min(3).max(80),
  displayName: z.string().min(2).max(120),
  city: z.string().min(2).max(80),
  batteryPercent: z.number().int().min(0).max(100),
  status: z.enum(["available", "assigned", "charging", "maintenance", "offline"]).default("offline")
});

export const updateVehicleStatusSchema = z.object({
  status: z.enum(["available", "assigned", "charging", "maintenance", "offline"]),
  batteryPercent: z.number().int().min(0).max(100).optional()
});
