# Driverless Fleet Operations API

Representative Node.js/TypeScript backend sample for a driverless fleet operations environment.

## Demonstrates
- Node.js + TypeScript service structure
- MongoDB-style models
- REST endpoints for vehicles, dispatch jobs and health checks
- input validation with Zod
- centralized error handling
- clear operational status responses
- Docker-ready development setup

## Example endpoints

```http
GET    /health
GET    /api/vehicles
POST   /api/vehicles
PATCH  /api/vehicles/:id/status
GET    /api/dispatch-jobs
POST   /api/dispatch-jobs
PATCH  /api/dispatch-jobs/:id/complete
```

## Run locally

```bash
npm install
cp .env.example .env
npm run dev
```

## Why this is relevant

Bliq's backend role involves product-facing and internal systems around driverless operations. This sample focuses on backend ownership, reliability, operational visibility and clean implementation boundaries.
