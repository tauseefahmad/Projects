# Backend / Full-Stack Work Samples — Tauseef Ahmad Awan

These are representative, non-confidential work samples prepared to demonstrate engineering style for backend/full-stack roles involving Node.js, TypeScript, MongoDB, React, CI/CD, reliability and AI-assisted development.

Some previous professional work cannot be shared publicly because it belongs to employers or research institutions. Therefore, this repository contains clean sample implementations that reflect the same engineering habits I apply in real work: structured APIs, validation, error handling, documentation, reproducibility, database-aware thinking and maintainable code organization.

## Included samples

### 1. Driverless Fleet Operations API
A compact TypeScript/Node.js backend sample for vehicle status, dispatch jobs and operational health checks.

Relevant to Bliq:
- Node.js + TypeScript backend
- MongoDB-style data modeling
- REST API design
- structured service/controller separation
- validation and error handling
- operational health endpoint
- Docker-ready structure

### 2. Internal Operations Dashboard
A lightweight React/TypeScript dashboard mock-up for operations monitoring.

Relevant to Bliq:
- React + TypeScript
- stateful UI structure
- frontend/backend integration mindset
- operational visibility for fleet/internal teams

### 3. Engineering Notes
Short documents explaining architecture, reliability, AI-assisted development usage and production-readiness decisions.

## Important note

These samples are intentionally compact so they can be reviewed quickly. They are not intended to represent a full production system, but they show how I structure code, document trade-offs and think about reliability in product-facing engineering work.
