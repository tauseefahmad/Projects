# AI-Assisted Engineering Note

I use AI coding tools as a productivity multiplier, not as a substitute for engineering judgment.

Good uses:
- generating first drafts of boilerplate
- exploring implementation alternatives
- producing test-case ideas
- improving documentation clarity
- explaining unfamiliar libraries or APIs

Where I do not blindly rely on AI:
- security-sensitive logic
- data model decisions
- concurrency or state-transition correctness
- production incident reasoning
- final code review responsibility

For a fast-moving team, the value is not “AI writes the code.” The value is faster iteration while the engineer remains responsible for correctness, maintainability and production behavior.
