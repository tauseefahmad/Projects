# Architecture Decisions

## 1. Keep services small and explicit
The API separates routes, validation, service logic and persistence models. This makes it easier to test business rules independently from HTTP details.

## 2. Validate at the boundary
Zod schemas validate incoming payloads before the service layer is called. This avoids silent assumptions and makes API behavior predictable.

## 3. Prefer operational clarity
The health endpoint, request IDs, structured errors and clear status values are small but important reliability features. In operational systems, debugging speed matters.

## 4. Model state transitions carefully
Dispatch jobs and vehicles are linked through status transitions. In a production system, these updates should be protected by transactions, idempotency keys and stronger concurrency handling.
