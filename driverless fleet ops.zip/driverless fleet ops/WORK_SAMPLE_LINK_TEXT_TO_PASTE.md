# Suggested application-form text

My previous employer/research code is not fully public because of confidentiality, so I prepared representative work samples that demonstrate my relevant engineering style for this role:

- Node.js/TypeScript backend sample for driverless fleet operations
- MongoDB-style data modeling and REST API structure
- React/TypeScript internal operations dashboard
- Docker-ready setup and reliability notes
- AI-assisted engineering note showing how I use AI tools responsibly

Link: [paste your GitHub / Google Drive link here after upload]
